# Facebook Shooping Feed para  Magento 2

__Installation__
 
  1. Criar o Diretorio conforme informo abaixo
    `$ mkdir -p VertexNet/FacebookFeed` em  app/code 

  2. Faça o Upload de Todos os Arquivos para a pasta VertexNet/FacebookFeed 
 

  3. Execute o Comando do Magento 2 em seu SSH

    $ bin/magento setup:upgrade

  4. Limpe o Cache e generated

    $ bin/magento cache:clean

Faça o Login, vá até Loja > Configurações > Vertex Net > Facebook Feed

Para acessar o feed para facebook segue exemplo, onde www.website.com é o endereço de sua loja virtual : www.website.com/vertexnetfacebookfeed/
    
